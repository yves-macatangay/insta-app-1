<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* ACTIVITY: style the registration email with CSS */
    </style>
</head>
<body>
    <p>Hi, {{ $name }}!</p>
    <p>Thank you for registering to Kredo Insta App.</p>
    <p>To begin, visit the website <a href="{{ $app_url }}">here</a>.</p>
</body>
</html>